"""Task-specific command line workflows; generation reuses the original prompt logic."""
import argparse
import json
import time
from pathlib import Path

from spectroscopy import decoding as pipeline
from spectroscopy import scoring as metrics

PROJECT_ROOT = Path(__file__).resolve().parent

def load_data(path):
    from datasets import Dataset, concatenate_datasets
    files = sorted(Path(path).glob('*.arrow'))
    if not files:
        raise FileNotFoundError(f'No Arrow shards: {path}')
    data = concatenate_datasets([Dataset.from_file(str(p)) for p in files])
    missing = {'question', 'cot', 'answer'} - set(data.column_names)
    if missing:
        raise ValueError(f'Missing dataset columns: {missing}')
    if not len(data):
        raise ValueError('Empty dataset')
    return data

def checkpoint(path):
    root = Path(path).resolve()
    candidates = [root] if (root/'config.json').is_file() else sorted(p.parent for p in root.rglob('config.json'))
    candidates = [p for p in candidates if list(p.glob('*.safetensors')) or list(p.glob('pytorch_model*.bin'))]
    if len(candidates) != 1:
        raise ValueError(f'Expected one checkpoint under {root}; found {candidates}. Specify the exact checkpoint.')
    if not (candidates[0]/'tokenizer_config.json').is_file():
        raise FileNotFoundError(f'Missing tokenizer in {candidates[0]}')
    return candidates[0]

def verify_task(data):
    task = metrics.judge_task_from_answer_by_keyword(list(data['answer']))
    if task not in {'nmr', 'nmr_forward'}:
        raise ValueError(f'Task {task!r} is outside this project scope')
    return task

def infer(config):
    import torch
    from transformers import AutoTokenizer, AutoModelForCausalLM
    started = time.time()
    data = load_data(config['data'])
    total = len(data)
    task = verify_task(data)
    limit = config.get('limit', 3)
    if limit < 0:
        raise ValueError('limit must be >= 0 (0 means full dataset)')
    if limit:
        data = data.select(range(min(limit, len(data))))
    model_dir = checkpoint(config['model'])
    out = Path(config.get('output', 'runs/inference')).resolve()
    out.mkdir(parents=True, exist_ok=True)
    data.save_to_disk(str(out/'ground_truth'))
    tokenizer = AutoTokenizer.from_pretrained(str(model_dir), local_files_only=True)
    questions = [pipeline.standardize_shift_decimal_place(q, config.get('adjust_decimal_places', False), config.get('c_shift_decimal_place', 1), config.get('h_shift_decimal_place', 2)) for q in data['question']]
    prompts = pipeline.mapping_list_qusetion_to_certain_form(questions, tokenizer, pipeline.detect_qwen_model_type(str(model_dir)), False)
    backend = config.get('backend', 'transformers')
    beam = config.get('beam_width', 1)
    temperature = config.get('temperature', 0)
    max_tokens = config.get('max_tokens', 5000)
    details = []
    texts = []
    if backend == 'transformers':
        device = config.get('device', 'cuda:0')
        model = AutoModelForCausalLM.from_pretrained(str(model_dir), local_files_only=True, torch_dtype=torch.bfloat16 if device.startswith('cuda') else torch.float32).to(device).eval()
        for index, prompt in enumerate(prompts):
            inputs = tokenizer(prompt, return_tensors='pt', add_special_tokens=False).to(device)
            options = dict(max_new_tokens=max_tokens, do_sample=temperature > 0, num_beams=beam, num_return_sequences=beam, pad_token_id=tokenizer.pad_token_id or tokenizer.eos_token_id)
            if temperature > 0:
                options.update(temperature=temperature, top_p=config.get('top_p', .95), top_k=config.get('top_k', 20))
            with torch.inference_mode():
                generated = model.generate(**inputs, **options)
            continuations = generated[:, inputs['input_ids'].shape[1]:]
            candidates = [prompt + tokenizer.decode(tokens, skip_special_tokens=True) for tokens in continuations]
            texts.append(candidates)
            details.append({'index':index, 'input_tokens':inputs['input_ids'].shape[1], 'generated_tokens':len(continuations[0]), 'has_answer':bool(metrics.extract_str_answer(candidates[0])), 'reached_token_limit':len(continuations[0]) >= max_tokens})
            print(f'Generated {index+1}/{len(prompts)}: {details[-1]}', flush=True)
        del model
        if device.startswith('cuda'):
            torch.cuda.empty_cache()
    elif backend == 'vllm':
        from vllm import LLM, SamplingParams
        engine = LLM(model=str(model_dir), tensor_parallel_size=config.get('tensor_parallel_size', 1), gpu_memory_utilization=config.get('gpu_memory_utilization', .7))
        if beam > 1:
            from vllm.sampling_params import BeamSearchParams
            generated = engine.beam_search([{'prompt':p} for p in prompts], BeamSearchParams(beam_width=beam, max_tokens=max_tokens, temperature=temperature))
            texts = [[s.text for s in item.sequences] for item in generated]
        else:
            generated = engine.generate(prompts, SamplingParams(max_tokens=max_tokens, temperature=temperature, top_p=config.get('top_p', .95), top_k=config.get('top_k', 20)))
            texts = [[item.prompt+s.text for s in item.outputs] for item in generated]
    else:
        raise ValueError(f'Unknown backend {backend}')
    with (out/'predictions.jsonl').open('w') as handle:
        for candidates in texts:
            handle.write(json.dumps({'text':candidates}, ensure_ascii=False)+'\n')
    with (out/'predictions.txt').open('w') as handle:
        for candidates in texts:
            handle.write(candidates[0].replace('\n', '\\n').replace('\r', '\\r')+'\n')
    result = metrics.test_model_predict_result(str(out/'ground_truth'), str(out/'predictions.txt'))
    (out/'metrics.json').write_text(json.dumps(result, indent=2, ensure_ascii=False)+'\n')
    report = {'project':'NMRReasoner', 'task':task, 'model':str(model_dir), 'data':str(Path(config['data']).resolve()), 'dataset_rows':total, 'evaluated_rows':len(data), 'backend':backend, 'torch':torch.__version__, 'transformers':__import__('transformers').__version__, 'config':config, 'elapsed_seconds':time.time()-started, 'generation':details, 'metrics':result}
    (out/'validation.json').write_text(json.dumps(report, indent=2, ensure_ascii=False)+'\n')
    print(f'Results: {out}', flush=True)

def main(argv=None):
    parser = argparse.ArgumentParser(description='NMRReasoner')
    commands = parser.add_subparsers(dest='command', required=True)
    for command in ['inspect', 'infer']:
        p = commands.add_parser(command)
        p.add_argument('--config', default=str(PROJECT_ROOT/'experiments/local.json'))
        for name in ['data','model','output','backend','device']:
            p.add_argument('--'+name)
        for name in ['limit','max-tokens','beam-width']:
            p.add_argument('--'+name, type=int)
    p = commands.add_parser('evaluate')
    p.add_argument('--data', required=True)
    p.add_argument('--predictions', required=True, help='One prediction per line, TXT format')
    p.add_argument('--output', required=True)
    p = commands.add_parser('vote')
    p.add_argument('--data', required=True)
    p.add_argument('--predictions', nargs='+', required=True, help='JSONL paths, highest priority first')
    p.add_argument('--output', required=True)
    p.add_argument('--topk', type=int, default=10)
    p.add_argument('--workers', type=int, default=1)
    p = commands.add_parser('train')
    p.add_argument('--data', required=True)
    p.add_argument('--model', required=True)
    p.add_argument('--output', required=True)
    p.add_argument('--epochs', type=int, default=20)
    p.add_argument('--batch-size', type=int, default=64)
    args = parser.parse_args(argv)
    if args.command in ['inspect', 'infer']:
        config = json.loads(Path(args.config).read_text())
        for key,value in vars(args).items():
            if key not in ['command','config'] and value is not None:
                config[key] = value
        if args.command == 'infer':
            infer(config)
        else:
            data = load_data(config['data'])
            print(json.dumps({'rows':len(data), 'columns':data.column_names, 'task':verify_task(data), 'checkpoint':str(checkpoint(config['model'])), 'first_question':data[0]['question']}, indent=2, ensure_ascii=False))
    elif args.command == 'evaluate':
        data = load_data(args.data)
        verify_task(data)
        lines = Path(args.predictions).read_text().splitlines()
        if len(lines) != len(data):
            raise ValueError(f'Prediction count {len(lines)} != dataset count {len(data)}')
        result = metrics.test_model_predict_result(args.data, args.predictions)
        dest = Path(args.output); dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_text(json.dumps(result, indent=2, ensure_ascii=False)+'\n')
    elif args.command == 'vote':
        from spectroscopy.voting import cot_sc_multi_jsonl_topk_result_to_dict_key_str_topk_value_float_acc
        verify_task(load_data(args.data))
        cot_sc_multi_jsonl_topk_result_to_dict_key_str_topk_value_float_acc(args.data, args.predictions, args.output, 'consensus', topk=args.topk, num_process=args.workers, check_nmr_formula=True)
    elif args.command == 'train':
        import os
        verify_task(load_data(args.data))
        os.environ.update(REASONER_TRAIN_DATA=str(Path(args.data).resolve()), REASONER_BASE_MODEL=str(Path(args.model).resolve()), REASONER_EPOCHS=str(args.epochs), REASONER_BATCH_SIZE=str(args.batch_size))
        out = Path(args.output).resolve();out.mkdir(parents=True, exist_ok=True);os.chdir(out)
        from experiments.fit import main as fit
        fit()

if __name__ == '__main__':
    main()
