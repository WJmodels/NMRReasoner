# NMRReasoner · Spectral Reasoning Workbench

Infer molecular structures as SMILES from molecular formulas and NMR measurements. The project also retains training, inference, and evaluation for predicting ¹H / ¹³C chemical shifts from molecular structures.

This directory follows an experiment-oriented layout. Use `test.py` for inference and evaluation and `train.py` for fine-tuning, without installing a project package; experiment settings live in `experiments/`, and spectral processing lives in `spectroscopy/`.

> Experiment flow: inspect inputs → generate structures → save predictions → calculate chemical metrics → review the record.

### Run your first experiment

The two reproduction entry points are `python test.py` and `python train.py`. Run either with `--help` to see its arguments. `test.py` defaults to inference and also provides `inspect`, `evaluate`, and `vote` subcommands. The existing `run.py` workflow interface remains available.

From this directory, use the existing environment:

```bash
cd /home/wanglab/lln/project/CLReasoner/NMRReasoner
PY=/opt/anaconda3/envs/unsloth_py312_260316/bin/python
$PY test.py inspect
CUDA_VISIBLE_DEVICES=0 $PY test.py --output runs/solvent_smoke
```

The default preset, `experiments/local.json`, points to the solvent test set containing **22,188** examples. It selects the first three examples and allows up to 5,000 new tokens per example. The checkpoint resolves to `depth1_real_393034/outputs/checkpoint-73698`. To evaluate the full dataset:

```bash
CUDA_VISIBLE_DEVICES=0 $PY test.py --limit 0 --output runs/solvent_full
```

The original `/home/sunhnayu/...` paths are unavailable on this machine. The preset uses absolute paths to assets with matching names under this workspace's `../test/data` and `../test/weight`. When moving the project, update `data` and `model` in the JSON preset or pass `--data` and `--model`. If a model directory contains multiple checkpoints, specify the exact checkpoint directory.

### Where experiment records go

Each `infer` run writes these files to its output directory:

- `ground_truth/`: the selected Arrow examples, aligned with the predictions.
- `predictions.jsonl`: full prompts and candidate answers; `text` is a list of strings.
- `predictions.txt`: the first candidate for each example, with embedded newlines escaped.
- `metrics.json`: chemical evaluation results using the original scorer.
- `validation.json`: dataset size, model path, settings, environment versions, elapsed time, and generation completeness.

The completed checkpoint smoke test is documented in [validation/REPORT.md](validation/REPORT.md). A small sample establishes that the pipeline executes; it does not measure full-dataset accuracy. Checkpoint loading and inference have been verified. The model has not been retrained.

### Try another experiment

**Recalculate metrics.** The prediction count must match the number of dataset examples.

```bash
$PY test.py evaluate --data runs/solvent_smoke/ground_truth \
  --predictions runs/solvent_smoke/predictions.txt --output runs/rescore.json
```

**Vote across prediction sets.** List JSONL files in descending priority. Tie-breaking, SMILES normalization, and NMR molecular-formula filtering follow the original algorithm.

```bash
$PY test.py vote --data /path/to/arrow_test \
  --predictions first.jsonl second.jsonl --topk 10 --workers 1 --output runs/voting
```

**Fine-tune a model.** Supply an Arrow training dataset with `question`, `cot`, and `answer` columns.

```bash
$PY train.py --data /path/to/arrow_train --model /path/to/base_model \
  --epochs 20 --batch-size 64 --output runs/fit
```

Training retains the original Unsloth settings and the `question<think>cot</think><answer>answer</answer>` template. Additional training settings are in `experiments/fit.py`; importing that module does not start training. Provide a separate training dataset. The default test preset is intended for inference validation.

**Change decoding settings.** Transformers is the default backend. After installing vLLM, select it with `--backend vllm`; use `--beam-width 3` for beam search. Other sampling and shift-precision settings belong in the JSON preset: `temperature`, `top_p`, `top_k`, `adjust_decimal_places`, `c_shift_decimal_place`, and `h_shift_decimal_place`. Select GPUs through the external `CUDA_VISIBLE_DEVICES` environment variable.

### Find the code you need

| What you want to change | Where to look |
| :--- | :--- |
| Inference and evaluation entry point | `test.py` → `workflows.py` |
| Training entry point | `train.py` → `workflows.py` |
| Sample selection and result records | `workflows.py` |
| Prompts, Arrow loading, shift precision, original batch inference | `spectroscopy/decoding.py` |
| Structure accuracy, Tanimoto similarity, chemical-shift errors | `spectroscopy/scoring.py` |
| Candidate filtering, formula checks, self-consistency voting | `spectroscopy/voting.py` |
| Fine-tuning and training logs | `experiments/fit.py` |
| Local assets and default settings | `experiments/local.json` |
| Lightweight regression checks | `checks/test_workflow.py` |

Structure elucidation retains the original chirality-removal and chemical-normalization rules. Spectral prediction retains MAE, MSE, RMSD, and peak-count difference statistics. `infer` scores the first candidate; run `vote` for Top-K aggregation. The original evaluation filters are also preserved, so compare metrics only when their evaluation settings agree.

### Set up a fresh environment

For standard inference, run `pip install -r requirements.txt`. For training or vLLM, use the environment matching the original dependency versions:

```bash
conda env create -f runtime.yml
conda activate nmrreasoner
python test.py --help
python train.py --help
python -m unittest discover -s checks -v
```

The local validation used PyTorch 2.10.0+cu128 and Transformers 5.2.0. `runtime.yml` preserves the original version pins and adds RDKit; numerical results may differ between inference environments. This project runs independently of the other Reasoner and the original CLReasoner directory. External dataset and model paths are supplied through configuration.
